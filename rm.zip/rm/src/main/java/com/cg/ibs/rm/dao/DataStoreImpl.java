package com.cg.ibs.rm.dao;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.cg.ibs.rm.bean.AutoPayment;
import com.cg.ibs.rm.bean.Beneficiary;
import com.cg.ibs.rm.bean.CreditCard;
import com.cg.ibs.rm.bean.FinalCustomer;
import com.cg.ibs.rm.bean.ServiceProvider;
import com.cg.ibs.rm.bean.TemporaryCustomer;

public class DataStoreImpl {

	private static Map<String, FinalCustomer> finalMap = new HashMap<>();
	private static Map<String, TemporaryCustomer> tempMap = new HashMap<>();
	private static Set<ServiceProvider> providers = new HashSet<>();

	public static Set<ServiceProvider> getProviders() {
		return providers;
	}

	public static void setProviders(Set<ServiceProvider> providers) {
		DataStoreImpl.providers = providers;
	}

	public static Map<String, FinalCustomer> getFinalMap() {
		return finalMap;
	}

	public static Map<String, TemporaryCustomer> getTempMap() {
		return tempMap;
	}

	private static FinalCustomer finalCustomer = new FinalCustomer();
	private static Set<AutoPayment> savedAutoPaymentServices1 = new HashSet<>();
	private static Set<AutoPayment> savedAutoPaymentServices2, savedAutoPaymentServices3;
	private static Set<CreditCard> unapprovedCreditCards3;
	private static List<Beneficiary> unapprovedBeneficiaries3;
	private static List<Beneficiary> savedBeneficiaries1, savedBeneficiaries2;
	private static Set<CreditCard> savedCreditCards1, savedCreditCards2;
	private static TemporaryCustomer tempCustomer = new TemporaryCustomer();
	private static AutoPayment autoPayment1 = new AutoPayment();
	private static CreditCard creditCard1 = new CreditCard();
	private static Beneficiary beneficiary1 = new Beneficiary();
	private static AutoPayment autoPayment2 = new AutoPayment();
	private static AutoPayment autoPayment3 = new AutoPayment();
	private static CreditCard creditCard3 = new CreditCard();
	
	static {
		
		autoPayment1.setAmount(new BigDecimal("500"));
		autoPayment1.setDateOfStart("12/12/2019");
		autoPayment1.setServiceProviderId(new BigInteger("1"));
		savedAutoPaymentServices1.add(autoPayment1);

		
		creditCard1.setcreditCardNumber(new BigInteger("235167231425"));
		creditCard1.setnameOnCreditCard("Shubham Gupta");
		creditCard1.setcreditDateOfExpiry(LocalDate.of(2022, 8, 10));
		savedCreditCards1.add(creditCard1);
		
		beneficiary1.setAccountName("Ramesh Ranjan");
		beneficiary1.setAccountNumber(new BigInteger("3498256715894562"));
		beneficiary1.setBankName("HDFC");
		beneficiary1.setIfscCode("HDFC5478321");
		// beneficiary.setType(type.SELFINOTHERS);
		savedBeneficiaries1.add(beneficiary1);
		finalCustomer.setUCI("12345");
		finalCustomer.setCurrentBalance(new BigDecimal("100000"));
		finalCustomer.setSavedAutoPaymentServices(savedAutoPaymentServices1);
		finalMap.put("12345", finalCustomer);

		
		autoPayment2.setAmount(new BigDecimal("1000"));
		autoPayment2.setDateOfStart("10/1/2020");
		autoPayment2.setServiceProviderId(new BigInteger("1"));

		savedAutoPaymentServices2.add(autoPayment2);

		CreditCard creditCard2 = new CreditCard();
		creditCard2.setcreditCardNumber(new BigInteger("561234567819"));
		creditCard2.setnameOnCreditCard("Ayush Kumar");
		creditCard2.setcreditDateOfExpiry(LocalDate.of(2024, 11, 15));
		savedCreditCards2.add(creditCard2);
		Beneficiary beneficiary2 = new Beneficiary();
		beneficiary2.setAccountName("Suraj Lohar");
		beneficiary2.setAccountNumber(new BigInteger("5479254792074527"));
		beneficiary2.setBankName("IDFC");
		beneficiary2.setIfscCode("IDFC2435612");
		// beneficiary.setType();
		savedBeneficiaries2.add(beneficiary2);
		finalCustomer.setUCI("123456");
		finalCustomer.setCurrentBalance(new BigDecimal("100000"));
		finalCustomer.setSavedAutoPaymentServices(savedAutoPaymentServices2);
		finalMap.put("123456", finalCustomer);

		
		autoPayment3.setAmount(new BigDecimal("1500"));
		autoPayment3.setDateOfStart("12/10/2019");
		autoPayment3.setServiceProviderId(new BigInteger("2"));
		savedAutoPaymentServices3.add(autoPayment3);

		
		creditCard3.setcreditCardNumber(new BigInteger("354278945617"));
		creditCard3.setnameOnCreditCard("Shivani Das");
		creditCard3.setcreditDateOfExpiry(LocalDate.of(2023, 10, 10));
		unapprovedCreditCards3.add(creditCard3);
		Beneficiary beneficiary3 = new Beneficiary();
		beneficiary3.setAccountName("Adharsh Sharma");
		beneficiary3.setAccountNumber(new BigInteger("8794361278956743"));
		beneficiary3.setBankName("Kotak Mahindra");
		beneficiary3.setIfscCode("KKBK3425167");
		// beneficiary.setType();
		unapprovedBeneficiaries3.add(beneficiary3);
		tempCustomer.setUCI("1234567");
		finalCustomer.setCurrentBalance(new BigDecimal("100000"));
		finalCustomer.setSavedAutoPaymentServices(savedAutoPaymentServices3);
		tempMap.put("1234567", tempCustomer);
	}
}