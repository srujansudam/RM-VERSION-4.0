package com.cg.ibs.rm.dao;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.cg.ibs.rm.bean.Beneficiary;
import com.cg.ibs.rm.bean.CreditCard;
import com.cg.ibs.rm.bean.FinalCustomer;
import com.cg.ibs.rm.bean.TemporaryCustomer;
import com.cg.ibs.rm.exception.ExceptionMessages;
import com.cg.ibs.rm.exception.RmExceptions;

public class BankRepresentativeDAOImpl implements BankRepresentativeDAO {

	Set<String> idList;
	Set<CreditCard> creditCardList;
	List<Beneficiary> beneficiaryList;

	Map<String, TemporaryCustomer> tempMap = DataStoreImpl.getTempMap();
	Map<String, FinalCustomer> finalMap = DataStoreImpl.getFinalMap();

	public Set<String> getRequests() {
		idList = tempMap.keySet();
		return idList;
	}

	public List<Beneficiary> getBeneficiaryDetails(String uci) throws RmExceptions {
		if (!(finalMap.containsKey(uci))) {
			throw new RmExceptions(ExceptionMessages.ERROR5);
		}
		beneficiaryList = tempMap.get(uci).getUnapprovedBeneficiaries();
		return beneficiaryList;
	}

	public Set<CreditCard> getCreditCardDetails(String uci) throws RmExceptions {
		if (!(finalMap.containsKey(uci))) {
			throw new RmExceptions(ExceptionMessages.ERROR5);
		}
		creditCardList = tempMap.get(uci).getUnapprovedCreditCards();
		return creditCardList;
	}

	@Override
	public void copyCreditCardDetails(String uci, CreditCard card) {
		FinalCustomer finalCustomer = DataStoreImpl.getFinalMap().get(uci);
		finalCustomer.getSavedCreditCards().add(card);
		finalMap.put(uci, finalCustomer);

	}

	public void deleteTempCreditCardDetails(String uci, CreditCard card) {

		TemporaryCustomer temporaryCustomer = DataStoreImpl.getTempMap().get(uci);
		if (tempMap.get(uci).getUnapprovedCreditCards().contains(card)) {
			temporaryCustomer.getUnapprovedCreditCards().remove(card);
			tempMap.put(uci, temporaryCustomer);
		}
	}

	public void deleteTempBeneficiaryDetails(String uci, Beneficiary beneficiary) {
		TemporaryCustomer temporaryCustomer = DataStoreImpl.getTempMap().get(uci);
		if (tempMap.get(uci).getUnapprovedBeneficiaries().contains(beneficiary)) {
			temporaryCustomer.getUnapprovedBeneficiaries().remove(beneficiary);
			tempMap.put(uci, temporaryCustomer);
		}

	}

	@Override
	public void copyBeneficiaryDetails(String uci, Beneficiary beneficiary) {
		FinalCustomer finalCustomer = DataStoreImpl.getFinalMap().get(uci);
		finalCustomer.getSavedBeneficiaries().add(beneficiary);
		finalMap.put(uci, finalCustomer);
	}

}
