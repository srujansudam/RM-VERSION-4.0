package com.cg.ibs.rm.ui;

import java.util.Map;

import com.cg.ibs.rm.bean.FinalCustomer;
import com.cg.ibs.rm.dao.DataStoreImpl;

public class Try {
public static void main(String[] args) {
	Map<String, FinalCustomer> map = DataStoreImpl.getFinalMap();
	System.out.println(map);
}
}
