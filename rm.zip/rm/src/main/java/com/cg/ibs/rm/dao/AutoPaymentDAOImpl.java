package com.cg.ibs.rm.dao;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import com.cg.ibs.rm.bean.AutoPayment;
import com.cg.ibs.rm.bean.FinalCustomer;
import com.cg.ibs.rm.bean.ServiceProvider;
import com.cg.ibs.rm.exception.ExceptionMessages;
import com.cg.ibs.rm.exception.RmExceptions;

public class AutoPaymentDAOImpl implements AutoPaymentDAO {

	Map<String, FinalCustomer> finalMap = DataStoreImpl.getFinalMap();
	Set<ServiceProvider> providers = DataStoreImpl.getProviders();
	BigDecimal bigDecimal;
    Iterator<AutoPayment> it;


	@Override
	public Set<AutoPayment> getAutopaymentDetails(String uci) {
		return finalMap.get(uci).getSavedAutoPaymentServices();

	}

	@Override
	public void copyDetails(String uci, AutoPayment autoPayment) {
		FinalCustomer finalCustomer = finalMap.get(uci);
		finalCustomer.getSavedAutoPaymentServices().add(autoPayment);
		finalCustomer.setSavedAutoPaymentServices(finalCustomer.getSavedAutoPaymentServices());
		finalMap.put(uci, finalCustomer);
		
	}

	@Override
	public boolean deleteDetails(String uci, BigInteger serviceProviderId) throws RmExceptions {
		boolean result = false;
		int count = 0;
		for (AutoPayment autoPayment : finalMap.get(uci).getSavedAutoPaymentServices()) {
			if (autoPayment.getServiceProviderId().equals(serviceProviderId)) {
				count++;
			}
		}
		if (0 == count) {
			throw new RmExceptions(ExceptionMessages.ERROR6);
		} else {
			it = finalMap.get(uci).getSavedAutoPaymentServices().iterator();
			while (it.hasNext()) {
				AutoPayment autoPayment = it.next();
				if (autoPayment.getServiceProviderId().equals(serviceProviderId)) {
					FinalCustomer finalCustomer = finalMap.get(uci);
					finalCustomer.getSavedAutoPaymentServices().remove(autoPayment);
					finalMap.put(uci, finalCustomer);
					
					result = true;
				}
			}
			return result;
		}
	}

	public Set<ServiceProvider> showServiceProviderList() {
		System.out.println(providers.isEmpty());
		return providers;
	}

	@Override
	public BigDecimal getCurrentBalance(String uci) {
		bigDecimal = finalMap.get(uci).getCurrentBalance();
		return bigDecimal;
	}

	@Override
	public void setCurrentBalance(String uci, BigDecimal currentBalnce) {
		FinalCustomer finalCustomer = finalMap.get(uci);
		finalCustomer.setCurrentBalance(currentBalnce);
		finalMap.put(uci, finalCustomer);
		
	}

}
